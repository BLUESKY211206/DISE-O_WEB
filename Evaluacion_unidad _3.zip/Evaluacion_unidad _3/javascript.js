
let carrito = JSON.parse(localStorage.getItem('carrito')) || [];


function agregarAlCarrito(nombre, precio) {
  carrito.push({ nombre, precio });
  localStorage.setItem('carrito', JSON.stringify(carrito));
  alert(`${nombre} agregado al carrito`);
}

function mostrarCarrito() {
  const lista = document.getElementById('lista-carrito');
  const total = document.getElementById('total');
  if (!lista) return;

  lista.innerHTML = '';
  let suma = 0;

  carrito.forEach((item, index) => {
    suma += item.precio;
    const li = document.createElement('li');
    li.textContent = `${item.nombre} - S/ ${item.precio.toFixed(2)}`;

    const btnEliminar = document.createElement('button');
    btnEliminar.textContent = "Eliminar";
    btnEliminar.onclick = () => eliminarDelCarrito(index);
    li.appendChild(btnEliminar);

    lista.appendChild(li);
  });

  total.textContent = `Total: S/ ${suma.toFixed(2)}`;
}

function eliminarDelCarrito(index) {
  carrito.splice(index, 1);
  localStorage.setItem('carrito', JSON.stringify(carrito));
  mostrarCarrito();
}


document.addEventListener("DOMContentLoaded", mostrarCarrito);
